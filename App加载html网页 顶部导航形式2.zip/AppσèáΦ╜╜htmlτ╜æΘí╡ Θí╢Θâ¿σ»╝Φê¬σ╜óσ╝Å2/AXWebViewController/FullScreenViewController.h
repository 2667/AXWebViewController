//
//  FullScreenViewController.h
//  AXWebViewController
//
//  Created by devedbox on 2017/11/6.
//  Copyright © 2017年 AiXing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FullScreenViewController : UIViewController

@end
