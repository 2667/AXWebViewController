//
//  WebViewController.h
//  AXWebViewController
//
//  Created by devedbox on 2017/9/7.
//  Copyright © 2017年 AiXing. All rights reserved.
//

#import "AXWebViewController.h"

@interface WebViewController : AXWebViewController

@end
